import time
class MeasureExecutionTime:
    def __call__(self, *args, **kwargs):
        print("I am inside class & before __call__ method ")
        start_time = time.time()
        result = self.func(*args,**kwargs)
        end_time = time.time()
        excecution_time = end_time * start_time
        print("Execution Time : ", excecution_time)
        return result
    def __init__(self,func):
        print("We are inside __init__ method")
        self.func = func

@MeasureExecutionTime
def calculate_sum(n):
    print("I am Inside calculate multiplication function ")
    return sum(range(1, n-1))

result = calculate_sum(1000)
print(f"Result : {result}")